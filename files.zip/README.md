# المرآة السيادية — دليل النشر على Replit

## خطوات النشر

### ١. إنشاء المشروع على Replit
- افتح replit.com وأنشئ مشروعاً جديداً
- اختر **Python** كلغة
- ارفع جميع الملفات

### ٢. ضبط المتغيرات السرية
في Replit، اذهب إلى **Secrets** وأضف:
```
ANTHROPIC_API_KEY=your_key_here
SECRET_KEY=اختر_كلمة_سر_طويلة_عشوائية
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_secret
PAYPAL_MODE=sandbox
```

### ٣. تثبيت المتطلبات
في Shell اكتب:
```bash
pip install -r requirements.txt
```

### ٤. تشغيل التطبيق
```bash
python app.py
```

---

## هيكل المشروع
```
sovereign-mirror/
├── app.py              ← التطبيق الرئيسي (Flask + SQLite + Anthropic)
├── requirements.txt    ← المتطلبات
├── .env.example        ← نموذج المتغيرات
└── templates/
    ├── index.html      ← الصفحة الرئيسية (Landing Page)
    ├── auth.html       ← تسجيل الدخول والإنشاء
    ├── mirror.html     ← واجهة المحادثة الرئيسية
    └── upgrade.html    ← صفحة الدفع (PayPal)
```

---

## بوابة PayPal

### للاختبار (Sandbox)
١. اذهب إلى developer.paypal.com
٢. أنشئ تطبيقاً جديداً
٣. انسخ Client ID وضعه في Secrets

### للإنتاج
غيّر `PAYPAL_MODE=live` وضع مفاتيح الإنتاج

---

## نظام الاشتراكات

| المستوى | الحد | السعر |
|---------|------|-------|
| مجاني | 3 رسائل/جلسة | $0 |
| سيادي | غير محدود | $29/شهر |

---

## التطوير القادم
- [ ] تفعيل PayPal Webhooks للتجديد التلقائي
- [ ] إضافة أرشيف الجلسات
- [ ] لوحة تحكم للمستخدم السيادي
- [ ] دعم اللغات الأخرى
